// src/lib/api/barbers.ts
import { api } from "./index";

export const barbersApi = {
  // Criar barbeiro
  create: (barbershopId: number, data: any) =>
    api.post(`barbers/barbershops/${barbershopId}`, data),

  // Listar barbeiros
  listByBarbershop: (barbershopId: number) =>
    api.get(`barbers/barbershops/${barbershopId}`),

  // Atualizar barbeiro
  update: (barbershopId: number, userId: number, data: any) =>
    api.patch(`barbers/barbershops/${barbershopId}/${userId}`, data),

  // Vincular Owner como barbeiro
  linkOwner: (barbershopId: number) =>
    api.post(`barbers/barbershops/${barbershopId}/owner`),
};
